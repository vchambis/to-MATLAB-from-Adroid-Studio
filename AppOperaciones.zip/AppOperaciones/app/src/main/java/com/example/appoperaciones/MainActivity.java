package com.example.appoperaciones;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
public EditText a;      // Primer valor
public EditText b;      // Segundo valor
public Button btn;      // Boton que ejecuta la funcion
public TextView sum;    // Variable que mostrara la Suma
public TextView rest;   // Variable que mostrara la Resta
public TextView mult;   // Variable que mostrara la Multiplicacion
public TextView div;    // Variable que mostrara la Division
public float a1;        // Primer valor tipo flotante
public float b1;        // Segundo valor tipo flotante
    static{
    System.loadLibrary("archivos");
    }
    public native float[] funct(float x, float y);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a = findViewById(R.id.valor1);
        b = findViewById(R.id.valor2);
        btn = findViewById(R.id.button);
        sum = findViewById(R.id.mostrar_suma);
        rest = findViewById(R.id.mostrar_resta);
        mult = findViewById(R.id.mostrar_mult);
        div = findViewById(R.id.mostrar_div);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a1 = Float.valueOf(a.getText().toString());
                b1 = Float.valueOf(b.getText().toString());
                float res[] = funct(a1,b1);
                String T1 = Float.toString(res[0]);
                String T2 = Float.toString(res[1]);
                String T3 = Float.toString(res[2]);
                String T4 = Float.toString(res[3]);
                sum.setText(T1);
                rest.setText(T2);
                mult.setText(T3);
                div.setText(T4);
            }
        });
    }
}
