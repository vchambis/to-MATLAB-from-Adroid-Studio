//
// File: operaciones_initialize.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//
#ifndef OPERACIONES_INITIALIZE_H
#define OPERACIONES_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "operaciones_types.h"

// Function Declarations
extern void operaciones_initialize();

#endif

//
// File trailer for operaciones_initialize.h
//
// [EOF]
//
