//
// Created by Asus on 10/04/2020.
//
#include <jni.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "operaciones.h"
 extern "C"
 JNIEXPORT jfloatArray JNICALL Java_com_example_appoperaciones_MainActivity_funct(JNIEnv* env, jobject thiz, jfloat a, jfloat b)
 {
     float s[1];
     float r[1];
     float m[1];
     float d[1];
     operaciones(a,b,s,r,m,d);
     jfloatArray jArray = env -> NewFloatArray(4);
     float res[4]={*s,*r,*m,*d};
     env->SetFloatArrayRegion(jArray,0,4,res);
     return jArray;
 }