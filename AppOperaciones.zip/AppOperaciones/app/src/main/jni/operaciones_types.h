//
// File: operaciones_types.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//
#ifndef OPERACIONES_TYPES_H
#define OPERACIONES_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for operaciones_types.h
//
// [EOF]
//
