//
// File: operaciones.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//
#ifndef OPERACIONES_H
#define OPERACIONES_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "operaciones_types.h"

// Function Declarations
extern void operaciones(float a, float b, float *s1, float *r1, float *m1, float
  *d1);

#endif

//
// File trailer for operaciones.h
//
// [EOF]
//
