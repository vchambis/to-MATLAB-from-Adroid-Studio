//
// File: operaciones_terminate.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//
#ifndef OPERACIONES_TERMINATE_H
#define OPERACIONES_TERMINATE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "operaciones_types.h"

// Function Declarations
extern void operaciones_terminate();

#endif

//
// File trailer for operaciones_terminate.h
//
// [EOF]
//
