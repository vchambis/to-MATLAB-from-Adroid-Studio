//
// File: operaciones.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//

// Include Files
#include "rt_nonfinite.h"
#include "operaciones.h"

// Function Definitions

//
// FUNCION de operaciones basicas
//    a = primer argumento de entrada
//    b = segundo argumento de entrada
// Arguments    : float a
//                float b
//                float *s1
//                float *r1
//                float *m1
//                float *d1
// Return Type  : void
//
void operaciones(float a, float b, float *s1, float *r1, float *m1, float *d1)
{
  *s1 = a + b;

  //  s1 = operacion suma
  *r1 = a - b;

  //  r1 = operacion resta
  *m1 = a * b;

  //  m1 = operacion multiplicacion
  *d1 = a / b;

  //  d1 = operacion division
}

//
// File trailer for operaciones.cpp
//
// [EOF]
//
