//
// File: operaciones_initialize.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 09-Apr-2020 09:29:18
//

// Include Files
#include "rt_nonfinite.h"
#include "operaciones.h"
#include "operaciones_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void operaciones_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for operaciones_initialize.cpp
//
// [EOF]
//
