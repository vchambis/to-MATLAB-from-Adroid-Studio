function [s1,r1, m1, d1] = operaciones(a,b)
% FUNCION de operaciones basicas
%   a = primer argumento de entrada
%   b = segundo argumento de entrada
s1 = a + b;     % s1 = operacion suma
r1 = a - b;     % r1 = operacion resta
m1 = a*b;       % m1 = operacion multiplicacion
d1 = a/b;       % d1 = operacion division
end

