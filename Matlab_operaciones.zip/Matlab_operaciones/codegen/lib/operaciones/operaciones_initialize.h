//
// File: operaciones_initialize.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 11-Apr-2020 07:26:01
//
#ifndef OPERACIONES_INITIALIZE_H
#define OPERACIONES_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "operaciones_types.h"

// Function Declarations
extern void operaciones_initialize();

#endif

//
// File trailer for operaciones_initialize.h
//
// [EOF]
//
