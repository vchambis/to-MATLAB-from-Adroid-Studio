//
// File: operaciones_terminate.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 11-Apr-2020 07:26:01
//

// Include Files
#include "rt_nonfinite.h"
#include "operaciones.h"
#include "operaciones_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void operaciones_terminate()
{
  // (no terminate code required)
}

//
// File trailer for operaciones_terminate.cpp
//
// [EOF]
//
