/*
 * File: _coder_operaciones_info.c
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 11-Apr-2020 07:26:01
 */

/* Include Files */
#include "_coder_operaciones_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char * data[10] = {
    "789ced5a4d73da46181619d7753ad3d6d34e3ac929991e7a6866908d49211f33311f22e0e00fb09c6032a92da405d6de95842430f4941fd2434f9d5e3ad3de7a"
    "eca17fa13df4d2bfd06b6f95108b41f18e68254bb6a2778659f67d619fddd78f9e77773193a86c271886f9c87c59ed778f99b17d6837cceaa4bdc1cc9b339e98",
    "b41f38fac4de6396e6be47e2df4e5a51910d3034ec0e8232d8e9e316d0cc8e2c60301d4652309405d9e0472a6034a02b6800a471a40d11e021065565a6538666"
    "07976642d38e15b2de17ba403cddef6346ebeae7d345b31d66263fc794f52fb9e4c769cefcac3a7c6e78cb2e78094a4bec26b332d3bbbd49f054ca786eeb4b38",
    "fcb4f591b864e8472df34fa98d8e140bd32ffc8f5df049bcdd9745032af25157902504a6f8bf78c4e75df049fc55a5c1bd2e3c62f734a5a309f89e45459dddce"
    "f1d55c9eada7d6d6332dd65014d45286aca8484063db48118c541b0e81c49ad943b0c5ce2531394e5d80bcf9feafd77fe482e569d0cf45787843ca788bf2f033",
    "0a1ee12189cbb5edad8a0c11ff70ad9fd176cef00b6e6bf4ec7c1e7b2e386ef36028fda0c68f9fe78b5b62f3fcfbfba9d73a97707ceeedbc2d8d7d506f5bb5d9"
    "735d25e32f3bfae778cb639f0ee58e29f353bc1f3ce295a878b68fc45f55aa8b130360c45a3c18934255a06cb0569e9238501e3cf9e7cfdf635dbf24bca0747d",
    "7fa442fca0577fb90e5b52bad2aced6daf0f8ad1d1f5f8f99db779bead05be9f87badcc74083a2619dccfcd375b73a227605eb9038c5fbc923de2e15cff691b8"
    "775ecce4cb244880fcf8f1e59d58dfafbbbe3fdb381dedf73a1015f8c269bd97eff0a7075c84f43ddeb75fdc12bbac7dfb8aa3cf4c3fb732f6594b1505dd086b",
    "df1e9cbefbc40b2b592625e27b9968e005a5ef792dd5cd7127c546f764a7034abba574e92c55888ebe1f53be1f957b741a9e5f3a8c35090ea004c2caa7571dde"
    "72c123f1ffb5cfc682818416aba83a4bf29454e7e77f4c999f8f7c588fb80eff1ce639c2ab0edfa2e011fe91f8f0b0d9e43a39a8f5d203cc3de00f73b5138189",
    "8e0ec7fbec8b5b6261edb3fdd2f7b0f6d9b1befb8e37b658df17c38bf53d7e8e2f6a895d96aebf4fc15b3523966fb2ccd07ef7f4ca870a15cff691b8573e103a"
    "e0c978c1f1e10d7bb716df8f5f775dcf9ed5da078df45799f200d51f16b3d9aa722032b1ae5f95e758a5cc6f51dedd70f489dd747cdeb6cf37edf68be9fdcc1b",
    "caf88be6ef2e059fe48fc4c7679924940da0c9024a423ddf87c8a8c83bf6af7fa1d501afe7be0615cff691f87fe68ff5ba6f9f00ef93b4b1ceb4257180f5e071"
    "fcff3057b71e2c7a9fbe3be81572edf220cbd7d22391c372aad444e5b81e5c957a704c999fbfbcfbd237fdbf47c123f9227187feeba280c0502d2858150cd842",
    "a1ddeffcea11ef908a67fb48dc1ffd7f2b6d61f0e7ebdf3e8df47d4fa87841d581aea46acdc6379cd8c914ab99d1465fc8d5b2f9b80ebc5b75e0d1a65fbcfb84"
    "8247f245e28e3a60aedef65fd77ba0e7543cdb47e2fee8bf99ae095362bd8f065e507adfc9e747526683e39ac3d4a0fc9c87c543ad1e817dffbfebf43f4d",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 15288U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties()
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("operaciones"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.3.0.713579 (R2017b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_operaciones_info.c
 *
 * [EOF]
 */
