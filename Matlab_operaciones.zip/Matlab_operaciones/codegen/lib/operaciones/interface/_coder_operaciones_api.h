/*
 * File: _coder_operaciones_api.h
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 11-Apr-2020 07:26:01
 */

#ifndef _CODER_OPERACIONES_API_H
#define _CODER_OPERACIONES_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_operaciones_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void operaciones(real32_T a, real32_T b, real32_T *s1, real32_T *r1,
  real32_T *m1, real32_T *d1);
extern void operaciones_api(const mxArray * const prhs[2], const mxArray *plhs[4]);
extern void operaciones_atexit(void);
extern void operaciones_initialize(void);
extern void operaciones_terminate(void);
extern void operaciones_xil_terminate(void);

#endif

/*
 * File trailer for _coder_operaciones_api.h
 *
 * [EOF]
 */
