/* 
 * File: _coder_operaciones_info.h 
 *  
 * MATLAB Coder version            : 3.4 
 * C/C++ source code generated on  : 11-Apr-2020 07:26:01 
 */

#ifndef _CODER_OPERACIONES_INFO_H
#define _CODER_OPERACIONES_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
/* 
 * File trailer for _coder_operaciones_info.h 
 *  
 * [EOF] 
 */
