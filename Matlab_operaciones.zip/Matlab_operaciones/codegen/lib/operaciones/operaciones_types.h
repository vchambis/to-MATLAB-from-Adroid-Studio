//
// File: operaciones_types.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 11-Apr-2020 07:26:01
//
#ifndef OPERACIONES_TYPES_H
#define OPERACIONES_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for operaciones_types.h
//
// [EOF]
//
